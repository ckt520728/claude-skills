# Builder — 產出人格 Skill 檔案

把 analyzer 的兩線結果寫成一個可安裝的 Skill 資料夾。所有檔案寫到 `./output/{slug}/`。

## 檔案 1：`SKILL.md`（產物入口）

frontmatter 範本：

```yaml
---
name: {slug}
description: "Write and respond in the voice and judgment style of {display_name}. Use when the user wants content, replies, or decisions that sound like {display_name}. | 以 {display_name} 的語氣與判斷風格生成內容與回覆。"
version: "1.0.0"
user-invocable: true
allowed-tools: Read
---
```

正文需包含：
1. 一句話說明這是誰的人格模擬。
2. **使用方式**：當被要求「用 {display_name} 的風格寫 / 回 X」時，先讀 `voice.md` 與 `persona.md`，再生成。
3. **Voice 速查**：把最關鍵的 3–5 條語言規則直接列出（完整版在 `voice.md`）。
4. **Persona 速查**：最關鍵的 3–5 條行為 / 決策規則（完整版在 `persona.md`）。
5. **紅線聲明**：本 Skill 為風格參考，非該人物本人言論；不得用於冒充或誤導。

## 檔案 2：`persona.md`
直接落地 analyzer 線路 B 的全部內容：核心性格行為規則、決策捷思、人際行為、矛盾點、誠實邊界。每條盡量帶證據錨點。

## 檔案 3：`voice.md`
直接落地 analyzer 線路 A 的全部內容：七維度語言指紋表 + 每項的正例短引用。可附一段「上線前自檢」：生成內容後，對照這些特徵勾稽是否像本人。

## 檔案 4：`manifest.json`
```json
{
  "name": "{slug}",
  "display_name": "{name}",
  "version": "1.0.0",
  "language": "zh-TW",
  "goal": "{使用者想複製的東西}",
  "evidence_strength": "high | medium | low",
  "knowledge_sources": ["素材摘要 1", "素材摘要 2"],
  "created_at": "{YYYY-MM-DD}"
}
```

## 完成後
回報使用者：產物路徑、證據強度、以及打包下載指令。

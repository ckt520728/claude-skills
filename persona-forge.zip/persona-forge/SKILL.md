---
name: persona-forge
description: "Distill any real person into a reusable persona skill from sample materials — chat logs, articles, transcripts, posts, or notes. Use when the user wants to capture someone's voice, writing style, decision habits, or personality into a callable, reusable skill. | 把任何真人蒸餾成可複用的人格 Skill：餵入對話記錄、文章、逐字稿、貼文或筆記，產出可重複呼叫、能模仿其語氣與決策風格的 Skill。"
argument-hint: "[name-or-slug]"
version: "1.0.0"
user-invocable: true
allowed-tools: Read, Write, Edit, Bash
---

> **Language / 語言**：本 Skill 支援中英文。依使用者第一句話的語言，全程用同一語言回覆。
> This skill is bilingual. Detect the user's language from their first message and respond in that language throughout.

> **Execution Root / 執行根目錄**：所有相對路徑（`prompts/...`、`references/...`、`output/...`）都相對於本 `SKILL.md` 所在目錄。不要硬塞 `cd ~/.claude/...` 之類的宿主路徑——當前工作目錄已經是正確的 skill 根目錄。

---

# persona-forge — 人格鑄造廠

把一個真人蒸餾成一個「可被呼叫的人格 Skill」。產物是一個獨立資料夾，內含 `SKILL.md` + `persona.md` + `voice.md` + `manifest.json`，可以直接安裝到任何支援 skills 的宿主，之後就能用該人物的語氣與判斷風格來生成內容、回覆訊息、做決策模擬。

設計原則：
- **純 prompt 驅動，零外部依賴**：不需要任何第三方平台 API 或 Python 套件。素材只透過「貼文字」或「上傳檔案」匯入，用內建 `Read` / `Write` / `Edit` / `Bash` 即可完成。
- **可追溯**：每條人格規則盡量錨定到原始素材中的具體證據，不憑空捏造。
- **可進化**：產出後可隨時追加素材或口頭糾正，版本可回溯。

---

## 觸發條件

當使用者說以下任意內容時啟動：
- `/persona-forge`
- 「幫我做一個人格 skill」
- 「我想蒸餾某某人」
- 「把這個人的風格做成 skill」
- 「複製某人的語氣 / 寫作風格」

進化模式（對已產出的人格 Skill）：
- 「我有新素材」/「再加一些資料」 → 追加模式
- 「這不對」/「他不會這樣講」/「他應該是…」 → 糾正模式
- `/persona-forge update {slug}`

管理操作（列出 / 刪除）：見最下方「管理操作」。

---

## 工具使用規則

| 任務 | 使用工具 |
|------|---------|
| 讀取 PDF / 圖片 / 截圖 | `Read`（原生支援） |
| 讀取 Markdown / TXT / 逐字稿 | `Read` |
| 寫入 / 更新 Skill 檔案 | `Write` / `Edit` |
| 建資料夾、打包、列出檔案 | `Bash` |

**產出位置**：每個人物存成 `./output/{slug}/`。`{slug}` 用人物代號的小寫英數＋連字號（例：`teacher-kong`、`steve-jobs`）。

---

## 主流程：鑄造一個新人格

### Step 1 — 意圖訪談（最多問 3 題）

讀取 `prompts/intake.md` 的引導，向使用者確認：

1. **代號 / 名字**（必填）— 用來命名 slug
2. **一句話定位**（可跳過）— 這個人是誰、什麼身分、什麼領域
3. **你想複製他的什麼？**（可跳過，但強烈建議問）
   - 例如：寫作語氣 / 說話口吻 / 決策判斷風格 / 待人接物方式 / 以上全部

收集後做一行確認，再進下一步。除名字外都可略過。

### Step 2 — 素材匯入

詢問使用者怎麼提供素材，列出兩種方式：

```
素材怎麼給我？（可混用，也可以說「沒有，直接憑描述生成」）

  [A] 上傳檔案
      PDF / 圖片截圖 / Markdown / TXT / 逐字稿 — 我用 Read 直接讀

  [B] 直接貼文字
      把對話記錄、文章、貼文、訪談內容貼進來
```

- 檔案：用 `Read` 逐一讀取，路徑由使用者提供。
- 貼文字：直接當作文本素材，無需任何工具。
- 若使用者說「沒有素材」：僅憑 Step 1 的描述生成，並在產物中標註「低證據強度」。

**素材品味原則**（影響蒸餾品質，請主動遵守）：
- 長文 > 金句；爭議/壓力下的反應 > 場面話；前後變化 > 固定標籤；一手原文 > 二手轉述。
- 不要把整篇長逐字稿原文搬進產物（版權與雜訊風險）；只保留結構化摘要與極短引用。

### Step 3 — 雙線分析

讀取 `prompts/analyzer.md`，沿兩條線拆解素材：

**線路 A — Voice（語言指紋）**
從素材中提取可觀察、可複現的表達特徵：
- 慣用句式、開場 / 收尾習慣、標點與排版習慣
- 高頻詞、口頭禪、專屬比喻
- 語氣強度、正式 / 口語程度、對讀者的稱呼方式
- 至少 2 個「正例」短引用（≤ 20 字）佐證每個特徵

**線路 B — Persona（人格與判斷）**
- 核心性格標籤 → 翻成**具體行為規則**（不要只寫形容詞）
- 決策模式 / 判斷捷思（他面對問題先看什麼）
- 人際與溝通行為（怎麼讚美、怎麼拒絕、怎麼給負面回饋）
- **矛盾點**（言行不一致之處，保留而非抹平）
- **誠實邊界**（素材不足、不確定的地方，明確標出）

### Step 4 — 預覽與確認

向使用者展示摘要（各 5–8 行）：

```
Voice 摘要：
  - 句式：{xxx}
  - 口頭禪：{xxx}
  - 語氣：{xxx}

Persona 摘要：
  - 核心性格：{xxx}
  - 決策模式：{xxx}
  - 誠實邊界：{xxx}

確認產出？還是要調整？
```

等使用者確認後再寫檔。

### Step 5 — 寫入檔案

使用者確認後，在 `./output/{slug}/` 下用 `Write` 產出以下檔案（格式參考 `references/output-template.md`）：

1. `SKILL.md` — 產物的入口，frontmatter 含 `name`、`description`、`version: "1.0.0"`，正文引用 `persona.md` 與 `voice.md`，並寫明「以此人格生成內容」的使用說明。
2. `persona.md` — Step 3 線路 B 的完整人格規則。
3. `voice.md` — Step 3 線路 A 的語言指紋與正例。
4. `manifest.json` — 元資料：
   ```json
   {
     "name": "{slug}",
     "display_name": "{name}",
     "version": "1.0.0",
     "language": "zh-TW | en",
     "goal": "{使用者想複製的東西}",
     "evidence_strength": "high | medium | low",
     "knowledge_sources": ["{素材摘要列表}"],
     "created_at": "{YYYY-MM-DD}"
   }
   ```

寫完後，回報使用者產物的完整路徑，並告知可用「打包」指令下載（見下方）。

---

## 進化模式

### 追加素材
1. 用 Step 2 的方式讀取新素材。
2. 先備份現有版本：
   ```bash
   cp -r "./output/{slug}" "./output/{slug}.bak.$(date +%Y%m%d%H%M%S)"
   ```
3. 用 `prompts/analyzer.md` 只分析增量，把新發現**併入** `persona.md` / `voice.md`（用 `Edit`，不要整檔重寫）。
4. 把 `manifest.json` 的 `version` 進位（1.0.0 → 1.1.0），更新 `knowledge_sources`。

### 對話糾正
使用者說「不對 / 他應該是…」時：
1. 讀取 `prompts/corrector.md` 判斷這是 Voice 問題還是 Persona 問題。
2. 用 `Edit` 修正對應檔案中的那條規則，並在該規則後加一行 `修正紀錄：{原本} → {更正}`。
3. `manifest.json` 的 `version` 進位（修補級，1.0.0 → 1.0.1）。

---

## 管理操作

列出已鑄造的人格：
```bash
ls -1 ./output
```

檢視某個人格的元資料：
```bash
cat "./output/{slug}/manifest.json"
```

打包供下載（產生 zip 到 output 根目錄）：
```bash
cd ./output && zip -r "{slug}.zip" "{slug}" && cd - >/dev/null
```

刪除某個人格（先跟使用者確認）：
```bash
rm -rf "./output/{slug}"
```

---

## 安全與品質紅線

- **絕不捏造**：素材沒有的特徵不要硬編。不確定就寫進「誠實邊界」。
- **不存長原文**：產物只放結構化摘要與極短引用（單則 ≤ 20 字），避免版權問題。
- **真人尊重**：這是風格模擬工具，不是冒充。產物 `SKILL.md` 須註明「本 Skill 為風格參考，非該人物本人言論」。

# persona-forge 人格鑄造廠

把任何真人蒸餾成一個**可複用的人格 Skill**。餵入素材（對話記錄、文章、逐字稿、貼文、筆記），產出一個能模仿其語氣與判斷風格的 Skill 資料夾。

## 特色
- **零外部依賴**：純 prompt 驅動，不需任何第三方平台 API 或 Python 套件。
- **素材彈性**：上傳檔案（PDF / 圖片 / MD / TXT）或直接貼文字。
- **可追溯**：每條人格規則錨定到原始素材證據。
- **可進化**：產出後可追加素材或口頭糾正，版本可回溯。

## 安裝

### 方式一：skills CLI
```bash
npx skills add <你的 repo 或本地路徑> --skill persona-forge
```

### 方式二：手動
把 `persona-forge/` 整個資料夾放進你的 skills 目錄：
- Claude Code（專案）：`.agents/skills/persona-forge/`
- Claude Code（全域）：`~/.agents/skills/persona-forge/`

## 使用
在支援 slash command 的宿主中輸入 `/persona-forge`，或直接說「幫我做一個某某人的人格 skill」。

流程：意圖訪談 → 素材匯入 → 雙線分析（Voice / Persona）→ 預覽確認 → 產出到 `output/{slug}/`。

## 目錄結構
```
persona-forge/
├── SKILL.md                       # 主入口與流程
├── README.md
├── LICENSE
├── prompts/
│   ├── intake.md                  # 意圖訪談
│   ├── analyzer.md                # 雙線分析
│   ├── builder.md                 # 產出檔案
│   └── corrector.md               # 對話糾正
├── references/
│   └── output-template.md         # 產物範本
└── output/                        # 鑄造出的人格放這裡
```

## 紅線
本工具用於**風格模擬**，非冒充。產物會註明「為風格參考，非該人物本人言論」。請勿用於誤導或假冒他人。

## 授權
MIT
